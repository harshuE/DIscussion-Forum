<?php
require 'config.php';

if (isset($_POST['submit'])) {
    $Discussion_ID = $_POST['Discussion_ID'];
    $Trainer_ID = $_POST['Trainer_ID'];
    $Author_Name = $_POST['Author_Name'];
    $Name_of_the_Forum = $_POST['Name_of_the_Forum'];
    $Discussion_Title = $_POST['Discussion_Title'];
    $Subject_of_the_Content = $_POST['Subject_of_the_Content'];
    $Discussion_Content = $_POST['Discussion_Content'];

    // Use prepared statements to update data safely
    $sql = "UPDATE discussion_forum
            SET Trainer_ID=?, Author_Name=?, Name_of_the_Forum=?, Discussion_Title=?, Subject_of_the_Content=?, Discussion_Content=?
            WHERE Discussion_ID=?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssi", $Trainer_ID, $Author_Name, $Name_of_the_Forum, $Discussion_Title, $Subject_of_the_Content, $Discussion_Content, $Discussion_ID);

    if ($stmt->execute()) {
        header("Location: discussion_detail.php");
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>
