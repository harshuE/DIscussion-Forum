<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Discussion Post</title>
    <link rel="icon" type="image/x-icon" href="cube2.png">
    <link rel="stylesheet" href="footer.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

    <!-- CSS Styles -->
    <style>
header{
background: linear-gradient(180deg, rgba(0,74,173,1) 0%, rgba(92,225,226,1) 100%);
  
    text-align:left;
    padding:2%;
}  
h1{
    color: black;
    font-family: Georgia, 'Times New Roman', Times, serif;
}
.container{
    max-width: 1000px;
    margin: 3%;
    padding: 2%;
    background: linear-gradient(to bottom, #74EBD5, #9FACE6);;
    border-radius: 5px;
}
form{
    padding : 20px;
    border:1px solid silver;
    border-radius :5px;
    background-color: silver;
}
label{
    display:block;
    margin-bottom:10px;
}
textarea{
    width: 90%;
    padding:1%;
    margin-bottom: 10px;
    border: 1px;
}
.error.message{
    color: red;
}
</style>
</head>
<body>
    <!-- Your Header and Navigation -->

    <header>
        <h1>Edit Discussion Forum Post</h1>
    </header>

    <!-- Form Begins -->
    <div class="container">
        <form method="post" action="editdis.php">
            <!-- Include PHP to fetch and pre-fill the form fields with existing data -->
            <?php
            require 'config.php';

            if (isset($_GET['Discussion_ID'])) {
                $Discussion_ID = $_GET['Discussion_ID'];

                $sql = "SELECT * FROM discussion_forum WHERE Discussion_ID = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("i", $Discussion_ID);
                $stmt->execute();
                $result = $stmt->get_result();
                $row = $result->fetch_assoc();
            }
            ?>

            <input type="hidden" name="Discussion_ID" value="<?php echo $row['Discussion_ID']; ?>">

            <label for="Trainer_ID">Trainer ID</label>
            <input type="text" id="Trainer_ID" name="Trainer_ID" value="<?php echo $row['Trainer_ID']; ?>" required>

            <label for="Author_Name">Author Name</label>
            <input type="text" id="Author_Name" name="Author_Name" value="<?php echo $row['Author_Name']; ?>" required>

            <label for="Name_of_the_Forum">Name of the Forum</label>
            <input type="text" id="Name_of_the_Forum" name="Name_of_the_Forum" value="<?php echo $row['Name_of_the_Forum']; ?>" required>

            <label for="Discussion_Title">Discussion Title</label>
            <input type="text" id="Discussion_Title" name="Discussion_Title" value="<?php echo $row['Discussion_Title']; ?>" required>

            <label for="Subject_of_the_Content">Subject of the Content</label>
            <input type="text" id="Subject_of_the_Content" name="Subject_of_the_Content" value="<?php echo $row['Subject_of_the_Content']; ?>" required>

            <label for="Discussion_Content">Discussion Content</label>
            <textarea id="Discussion_Content" name="Discussion_Content" rows="5" required><?php echo $row['Discussion_Content']; ?></textarea>

            <p class="error-message" id="error-message"></p>

            <button type="submit" name="submit">Update</button>



        </form>
    </div>

    <!-- Your Footer Section -->
</body>
</html>
