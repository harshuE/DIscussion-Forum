<?php
require 'config.php';

//Fetch data from the database

$sql= "SELECT * FROM discussion_forum";
$result = $conn->query ($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Page </title>
    <link rel="icon" type="image/x-icon" href="cube2.png">
    <link rel="stylesheet" href="footer.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
  
<style>
   .container{
    background: darkblue ;
    color:white;
    font-size: 16px;
    width: 100%;
    margin : 20px auto;
    padding : 40 px;
  
   }

   .btn-edit,.btn-delete{
    background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            padding: 5px 10px;
            cursor: pointer;
            margin-right: 10px;
   }
</style>
</head>

<body>
<div class="bod">
        <div>
            <img src="images\logo.png" alt="Website Logo" style="width:400px; height: 100px;" >
        </div>
        
    <div class="blink"><b>"Fueling your teaching passion daily"</b></div>
    <button class="btnsign">SignUp</button> 
    <button class="btnlog">Login</button>
    </div>

<div class="top">     
    <ul> 
        <li><a class="active" href="#"> <i class='bx bxs-home'></i>  Home </a></li>
        <li><a href="#"><i class='bx bxs-book' ></i> Courses </a></li>
        <li><a href="#"><i class='bx bxs-graduation' ></i>   Become a trainer </a></li>
        <li><a href="#"><i class='bx bxs-help-circle'></i>  FAQ </a></li>
        <li><a href="#"><i class='bx bxs-message-alt-error'></i>  About us </a></li>
        <li><a href="#"><i class='bx bxs-phone'></i> Contact us </a></li>
        <input type="text" placeholder="  Search..." class="search">
    </ul>
</div>  



<div class="container">
<h2> Discussion Forum</h2>
    <?php
    //Loop through the fetched data and generate cards for each course
    while ($row=$result->fetch_assoc()){
        ?>
    <div>
               
                <p>Discussion_ID: <?php echo $row['Discussion_ID']; ?></p>
                <p>Trainer_ID: <?php echo $row['Trainer_ID']; ?></p>
                <p>Author_Name: <?php echo $row['Author_Name']; ?></p>
                <p>Name_of_the_Forum: <?php echo $row['Name_of_the_Forum']; ?></p>
                <p>Discussion_Title: <?php echo $row['Discussion_Title']; ?></p>
                <p>Subject_of_the_Content: <?php echo $row['Subject_of_the_Content']; ?></p>
                <p>Discussion_Content: <?php echo $row['Discussion_Content']; ?></p>
               

                <a href="edit_discussion_form.php?Discussion_ID=<?php echo $row['Discussion_ID']; ?>" class ="btn-edit";>Edit</a>
                <a href="delete_discussion_confirmation.php?Discussion_ID=<?php echo $row['Discussion_ID']; ?>" class ="btn-delete";>Delete</a>
    </div>
    <?php
    }
    ?>
    </div>
    <div class="box2">
    <div>
        <img src="images\logo.png" alt="Website Logo" style="width:400px; height: 100px; border: 2px solid #5ce1e2;" >
    </div>
    <p class="para"> "Welcome to our online Teacher Trainer platform, where we empower educators with professional development, resources and support to enhance their teaching skills and impact students' lives."</p>

<div class="page">
    <a href="#">FAQs |</a>
    <a href="#">Terms and Conditions |</a>
    <a href="#">Contact us</a>
</div>

<p class="para1"> Follow us </p>
<div class="follow">
    <i class='bx bxl-facebook-square bx-md' style='color:#5ce1e2'  ></i>
    <i class='bx bxl-twitter bx-md' style='color:#5ce1e2' ></i>
    <i class='bx bxl-instagram-alt bx-md' style='color:#5ce1e2' ></i>
    <i class='bx bxl-google-plus-circle bx-md' style='color:#5ce1e2' ></i>
</div>

<div class="enter">
    <input type="email" placeholder="Enter your email">
</div>

<div class="subs">
    <button type="submit" class="sub"> Subscribe </button>
</div>

<div class="call"> 
    <div class="cl">
        <i class='bx bxs-phone-call' style='color:#000000'>
            <a href="tel:+94 77 123 4567" style="color: #000000;"> +94 77 123 4567</a>
        </i>
    </div>
    
</div>
</div>

</body>
</html>


