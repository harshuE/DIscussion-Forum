
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>New Post</title>
    <link rel="icon" type="image/x-icon" href="cube2.png">
    <link rel="stylesheet" href="footer.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

    <!--CSS-->
    <style>
header{
    background: linear-gradient(180deg, rgba(0,74,173,1) 0%, rgba(92,225,226,1) 100%);
    text-align:left;
    padding:2%;
    color: black;
    
}  
h1{
    color: black;
    font-family: Georgia, 'Times New Roman', Times, serif;
}
.container{
    max-width: 1000px;
    margin: 3%;
    padding: 2%;
    background: linear-gradient(to bottom, #74EBD5, #9FACE6);
    border-radius: 5px;
}
form{
    padding : 20px;
    border:1px solid silver;
    border-radius :5px;
    background-color: silver;
}
label{
    display:block;
    margin-bottom:10px;
}
textarea{
    width: 90%;
    padding:1%;
    margin-bottom: 10px;
    border: 1px;
}
.error-message{
    color: red;
}


</style>
</head>
<!--HTML Content-->
<body>
<div class="bod">
        <div>
            <img src="images/logo.png" alt="Website Logo" style="width:400px; height: 100px;" >
        </div>
        
    <div class="blink"><b>"Fueling your teaching passion daily"</b></div>
    <button class="btnsign">SignUp</button> 
    <button class="btnlog">Login</button>
    </div>

<div class="top">     
    <ul> 
        <li><a class="active" href="#"> <i class='bx bxs-home'></i>  Home </a></li>
        <li><a href="#"><i class='bx bxs-book' ></i> Courses </a></li>
        <li><a href="#"><i class='bx bxs-graduation' ></i>   Become a trainer </a></li>
        <li><a href="#"><i class='bx bxs-help-circle'></i>  FAQ </a></li>
        <li><a href="#"><i class='bx bxs-message-alt-error'></i>  About us </a></li>
        <li><a href="#"><i class='bx bxs-phone'></i> Contact us </a></li>
        <input type="text" placeholder="  Search..." class="search">
    </ul>
</div>  

    <header>
        <h1>New Post</h1>
    </header>

    <!--Form Begins-->
    <div class="container"> 
        <form id="discussion_forum" method = "post"  action= "<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
        <input type="hidden" name="ID" value="<?php echo $Discussion_ID ['Number']; ?>">
        <label for="Discussion_ID"> Discussion_ID </label>
        <input type="text" id="Discussion_ID" name ="Discussion_ID" oninput="validateDiscussionID ()" required>
        <span id="discussionIDError" style="color:red;"></span>

        <label for="Trainer_ID"> Trainer_ID </label>
        <input type="text" id="Trainer_ID" name ="Trainer_ID" required>

        <label for="Author_Name"> Author_Name</label>
        <input type="text" id="Author_Name" name ="Author_Name" required>

        <label for="Name_of_the_Forum"> Name_of_the_Forum</label>
        <input type="text" id="Name_of_the_Forum" name ="Name_of_the_Forum" required>

        <label for="Discussion_Title"> Discussion_Title </label>
        <input type="text" id="Discussion_Title" name ="Discussion_Title" required>

        <label for="Subject_of_the_Content"> Subject_of_the_Content </label>
        <input type="text" id="Subject_of_the_Content" name ="Subject_of_the_Content" required>

        <label for="Discussion_Content"> Discussion_Content </label>
        <textarea id="Discussion_content" name ="Discussion_Content" rows="5" required></textarea>


        <p class="error-message" id="error-message"></p>

        <input class = "sbtn" type="submit" name = "submit" value="Submit">
        </form>

        <!--php content-->

        <?php
require "config.php";
if(isset($_POST['submit']))
{
    $Discussion_ID = $_POST['Discussion_ID'];
    $Trainer_ID = $_POST ['Trainer_ID'];
    $Author_Name =$_POST ['Author_Name'];
    $Name_of_the_Forum= $_POST['Name_of_the_Forum'];
    $Discussion_Title=$_POST ['Discussion_Title'];
    $Subject_of_the_Content=$_POST['Subject_of_the_Content'];
    $Discussion_Content= $_POST['Discussion_Content'];

    //Use prepared statements to insert data safely

$sql="INSERT INTO discussion_forum(Discussion_ID,Trainer_ID,Author_Name,Name_of_the_Forum,Discussion_Title,Subject_of_the_Content,Discussion_Content)
      VALUES (?,?,?,?,?,?,?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param("sssssss", $Discussion_ID, $Trainer_ID, $Author_Name, $Name_of_the_Forum, $Discussion_Title,$Subject_of_the_Content,$Discussion_Content);

    if ($stmt->execute()) {
    
     header("Location: discussion_detail.php");
     } else {
    echo "Error: " . $stmt->error;
    }

$stmt->close();
}

$conn->close();
?>

    </div>
    <!--JS-->
    <script>
        function validateForm () {
            var Discussion_ID= document.getElementById("Discussion_ID").value;
            var Trainer_ID= document.getElementById ("Trainer_ID").value;
            var Author_Name=document.getElementById("Author_Name").value;
            var Name_of_the_Forum = document.getElementById ("Name_of_the_Forum").value;
            var Discussion_Title = document.getElementById("Discussion_Title").value;
            var Subject_of_the_Content = document.getElementById ("Subject_of_the_Content").value;
            var Discussion_Content= document.getElementById ("Discussion_Content").value;
            var errorMessage= document.getElementById("error-message");

            errorMessage.textContent="";

            if(Discussion_ID.trim () ===""|| Trainer_ID.trim()===""|| Author_Name.trim () === ""||Name_of_the_Forum.trim()==="" || Discussion_Title.trim()===""|| Subject_of_the_Content.trim ()===""|| Discussion_Content.trim()==="")
            {
                errorMessage.textContent="Please fill in all fields with relevant data";
                return false;
            }

        return true;

    }
    function validateDiscussionID() {
    const discussionIDInput = document.getElementById("Discussion_ID");
    const discussionIDError = document.getElementById("discussionIDError");
    
    const inputValue = discussionIDInput.value;
    const isNumeric = /^\d+$/.test(inputValue); // Check if the input is a positive integer.
    
    if (!isNumeric) {
        discussionIDError.textContent = "Please enter only numbers for Discussion ID.";
        discussionIDInput.setCustomValidity("Please enter only numbers for Discussion ID.");
    } else {
        discussionIDError.textContent = ""; // Clear the error message.
        discussionIDInput.setCustomValidity(""); // Clear the custom validation message.
    }
}
    </script>

<div class="box2">
    <div>
        <img src="images\logo.png" alt="Website Logo" style="width:400px; height: 100px; border: 2px solid #5ce1e2;" >
    </div>
    <p class="para"> "Welcome to our online Teacher Trainer platform, where we empower educators with professional development, resources and support to enhance their teaching skills and impact students' lives."</p>

<div class="page">
    <a href="#">FAQs |</a>
    <a href="#">Terms and Conditions |</a>
    <a href="#">Contact us</a>
</div>

<p class="para1"> Follow us </p>
<div class="follow">
    <i class='bx bxl-facebook-square bx-md' style='color:#5ce1e2'  ></i>
    <i class='bx bxl-twitter bx-md' style='color:#5ce1e2' ></i>
    <i class='bx bxl-instagram-alt bx-md' style='color:#5ce1e2' ></i>
    <i class='bx bxl-google-plus-circle bx-md' style='color:#5ce1e2' ></i>
</div>

<div class="enter">
    <input type="email" placeholder="Enter your email">
</div>

<div class="subs">
    <button type="submit" class="sub"> Subscribe </button>
</div>

<div class="call"> 
    <div class="cl">
        <i class='bx bxs-phone-call' style='color:#000000'>
            <a href="tel:+94 77 123 4567" style="color: #000000;"> +94 77 123 4567</a>
        </i>
    </div>
    
</div>
</div>


</body>
</html>