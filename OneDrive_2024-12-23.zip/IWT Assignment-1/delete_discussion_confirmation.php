 <!--php content-->
 <?php
require 'config.php';

if (isset($_GET['Discussion_ID'])) {
    $Discussion_ID = $_GET['Discussion_ID'];

    // Check if the user has confirmed the deletion
    if (isset($_GET['confirm']) && $_GET['confirm'] === 'yes') {
        // Delete the course from the database
        $sql = "DELETE FROM discussion_forum WHERE Discussion_ID = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $Discussion_ID);

        if ($stmt->execute()) {
            // Redirect to a page after successful deletion (readnewcourse.php)
            header("Location: discussion_detail.php");
        } else {
            echo "Error: " . $stmt->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete </title>
    <link rel="icon" type="image/x-icon" href="cube2.png">
    <link rel="stylesheet" href="footer.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>


    <style>
     .container{
    max-width: 1000px;
    margin: 3%;
    padding: 2%;
    background:linear-gradient(to bottom, #74EBD5, #9FACE6);
    border-radius: 5px;
        }

    </style>
</head>
<body>
<div class="bod">
        <div>
            <img src="images\logo.png" alt="Website Logo" style="width:400px; height: 100px;" >
        </div>
        
    <div class="blink"><b>"Fueling your teaching passion daily"</b></div>
    <button class="btnsign">SignUp</button> 
    <button class="btnlog">Login</button>
    </div>

<div class="top">     
    <ul> 
        <li><a class="active" href="#"> <i class='bx bxs-home'></i>  Home </a></li>
        <li><a href="#"><i class='bx bxs-book' ></i> Courses </a></li>
        <li><a href="#"><i class='bx bxs-graduation' ></i>   Become a trainer </a></li>
        <li><a href="#"><i class='bx bxs-help-circle'></i>  FAQ </a></li>
        <li><a href="#"><i class='bx bxs-message-alt-error'></i>  About us </a></li>
        <li><a href="#"><i class='bx bxs-phone'></i> Contact us </a></li>
        <input type="text" placeholder="  Search..." class="search">
    </ul>
</div>  


    <div class = "container">
        <h2> Are you sure to delete the record<h2>
        <a href="delete_discussion_confirmation.php?Discussion_ID=<?php echo $Discussion_ID; ?>&confirm=yes">
            <button>Yes</button>
        </a>
        <a href="discussion_detail.php">
            <button>No</button>
        </a>
    </div>
    <div class="box2">
    <div>
        <img src="images\logo.png" alt="Website Logo" style="width:400px; height: 100px; border: 2px solid #5ce1e2;" >
    </div>
    <p class="para"> "Welcome to our online Teacher Trainer platform, where we empower educators with professional development, resources and support to enhance their teaching skills and impact students' lives."</p>

<div class="page">
    <a href="#">FAQs |</a>
    <a href="#">Terms and Conditions |</a>
    <a href="#">Contact us</a>
</div>

<p class="para1"> Follow us </p>
<div class="follow">
    <i class='bx bxl-facebook-square bx-md' style='color:#5ce1e2'  ></i>
    <i class='bx bxl-twitter bx-md' style='color:#5ce1e2' ></i>
    <i class='bx bxl-instagram-alt bx-md' style='color:#5ce1e2' ></i>
    <i class='bx bxl-google-plus-circle bx-md' style='color:#5ce1e2' ></i>
</div>

<div class="enter">
    <input type="email" placeholder="Enter your email">
</div>

<div class="subs">
    <button type="submit" class="sub"> Subscribe </button>
</div>

<div class="call"> 
    <div class="cl">
        <i class='bx bxs-phone-call' style='color:#000000'>
            <a href="tel:+94 77 123 4567" style="color: #000000;"> +94 77 123 4567</a>
        </i>
    </div>
    
</div>
</div>

</body>
</html>


